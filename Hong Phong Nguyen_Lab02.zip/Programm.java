/*Assessment: Lab Excersixe 02
Student Name: Hong Phong Nguyen
Student Number: 041099229
Lab Professor Name: David Houtman
Lab Section Number: CST8116 341
Due Date: June 2,2023*/

import java.util.Scanner;

public class Programm {
public static void main(String[] args) {
	Scanner userInput = new Scanner(System.in);
	Motorcycle Motorcycle= new Motorcycle();//to make a variable named Motorcycle with Motorcycle data type.
	//vehicle identification number
	System.out.printf("please enter vehicle identification number:");
	String vin = userInput.nextLine();
	Motorcycle.setvIN(vin);
	
	//EngineSize
	System.out.printf("please enter engine size (cc): ");
	int engineSize=userInput.nextInt();
	Motorcycle.setEngineSize(engineSize);
	
	//InvoicePrice
	System.out.printf("please enter invoice price: ");
	double invoicePrice = userInput.nextDouble();
	Motorcycle.setInvoicePrice(invoicePrice);
	;
	
	//Report
	String report=Motorcycle.toString();
	System.out.printf(report);
	System.out.printf("Program by Hong Phong Nguyen");
}
}
