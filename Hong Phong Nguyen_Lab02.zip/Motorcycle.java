/*Assessment: Lab Excersixe 02
Student Name: Hong Phong Nguyen
Student Number: 041099229
Lab Professor Name: David Houtman
Lab Section Number: CST8116 341
Due Date: June 2,2023*/

public class Motorcycle {
	private	String vIN; 
	private int engineSize;
	private double invoicePrice;
	public Motorcycle() {}

	public Motorcycle(String vIN, int engineSize, double invoicePrice) {
		this.vIN = vIN;
		this.engineSize = engineSize;
		this.invoicePrice = invoicePrice;
	}

	public String getvIN() {
		return vIN;
	}

	public void setvIN(String vIN) {
		this.vIN = vIN;
	}

	public int getEngineSize() {
		return engineSize;
	}

	public void setEngineSize(int engineSize) {
		// use Math.round to round the number however it is needed to turn enginsize into double number first 
		//		so that i can divide it to ten and round the Number and then because i set engineSize is integer
		//		so i have to change the value to integer
		this.engineSize =(int)(Math.round((double)engineSize/10)*10);
	}

	public double getInvoicePrice() {
		return invoicePrice;
	}

	public void setInvoicePrice(double invoicePrice) {
		this.invoicePrice = invoicePrice;
	}

	public String toString() {
		// %s is for String,%d for integer and %f is for float and then i have to add variable respectively
		String result= String.format("%s,%d cc,$%.2f %n", vIN,engineSize,invoicePrice);
		return result;
	}
	
}
