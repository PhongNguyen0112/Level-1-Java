/*Assessment: Lab Excersixe 02
Student Name: Hong Phong Nguyen
Student Number: 041099229
Lab Professor Name: David Houtman
Lab Section Number: CST8116 341
Due Date: June 9,2023*/
import java.util.Scanner; // import Scanner class to get input from users

public class Programm {
public static void main(String[] args) {
	Scanner userInput= new Scanner(System.in);// create an object of scanner using new keyword
	double innerRadius;
	double outerRadius;
	
	Donut donut = new Donut();// create donut object with data type Donut
	
	System.out.print("please enter the inner radius: ");
	innerRadius = userInput.nextDouble();//assgin to innerRadius by reading double value
	donut.setInnerRadius(innerRadius);//using setOuterRadius method to pass the input to the parameter
	
	System.out.print("please enter the outer radius: ");
	outerRadius = userInput.nextDouble();//assgin to outerRadius by reading double value
	donut.setOuterRadius(outerRadius);//using setInnerRadius method to pass the input to the parameter
	
	System.out.printf("%s %.2f %n","Volume is:",donut.calculateVolume());// output with string and double value(to 2 decimal numbers)
	System.out.print("Programm by Hong Phong Nguyen");
	userInput.close();//close the object of scanner
}
}
