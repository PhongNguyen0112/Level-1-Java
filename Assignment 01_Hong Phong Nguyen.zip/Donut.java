/*Assessment: Lab Excersixe 02
Student Name: Hong Phong Nguyen
Student Number: 041099229
Lab Professor Name: David Houtman
Lab Section Number: CST8116 341
Due Date: June 9,2023*/
public class Donut {
	//defining properties and features 
	private double innerRadius;
	private double outerRadius;
	private double volume;
// default constructor
	public Donut() {
	}
// overloaded constructor
	public Donut(double innerRadius, double outerRadius) {
		this.innerRadius = innerRadius;
		this.outerRadius = outerRadius;
	}
// getter return the value of innterRadius
	public double getInnerRadius() {
		return innerRadius;
	}
// setter to change the value of innerRadius from users
	public void setInnerRadius(double innerRadius) {
		this.innerRadius = innerRadius;
	}
	// getter return the value of outerRadius
	public double getOuterRadius() {
		return outerRadius;
	}
	// setter to change the value of outerRadius from users
	public void setOuterRadius(double outerRadius) {
		this.outerRadius = outerRadius;
	}

//This volume formula follow the method from GeeksforGeeks
//	Reference:
//	How to find the Volume of a Torus? in GeeksforGeeks.org
//	https://www.geeksforgeeks.org/how-to-find-the-volume-of-a-torus/[Accessed 31 05 2023]
//	*
//	Math.PI in method follows the example from MDN Web Docs
//	Reference:
//	Math.Pi in developer.mozilla.org
//	https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Math/PI. [Accessed 06 06 2023]
//	*
//	Math.pow in method follow the example from MDN Web Docs
//	Reference:
//	Math.pow() in developer.mozilla.org
//	https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Math/pow [Accessed 06 06 2023]
//	
	public double calculateVolume() {
		this.volume = (0.25 * Math.pow(Math.PI, 2) * Math.pow((outerRadius - innerRadius), 2)
				* (outerRadius + innerRadius));
		return this.volume;
	}
}
