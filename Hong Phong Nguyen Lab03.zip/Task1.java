/*Assessment: Lab Excersixe 02
Student Name: Hong Phong Nguyen
Student Number: 041099229
Lab Professor Name: David Houtman
Lab Section Number: CST8116 341
Due Date: June 23,2023*/
public class Task1 {
	public static void main(String[] args) {
		// using printf() method to format String and assign values(%s for String,%d for
		// integer and %n for insert next line)
		// Byte information
		System.out.printf("byte," + "SIZE: " + "%d,BYTES: " + "%d,MIN_VALUE: " + "%d,MAX_VALUE: " + "%d %n", Byte.SIZE,
				Byte.BYTES, Byte.MIN_VALUE, Byte.MAX_VALUE);
		// Short information
		System.out.printf("short," + "SIZE: " + "%d,BYTES: " + "%d,MIN_VALUE: " + "%d,MAX_VALUE: " + "%d %n",
				Short.SIZE, Short.BYTES, Short.MIN_VALUE, Short.MAX_VALUE);
		// Integer information
		System.out.printf("int," + "SIZE: " + "%d,BYTES: " + "%d,MIN_VALUE: " + "%d,MAX_VALUE: " + "%d %n",
				Integer.SIZE, Integer.BYTES, Integer.MIN_VALUE, Integer.MAX_VALUE);
		// Long information
		System.out.printf("long," + "SIZE: " + "%d,BYTES: " + "%d,MIN_VALUE: " + "%d,MAX_VALUE: " + "%d %n", Long.SIZE,
				Long.BYTES, Long.MIN_VALUE, Long.MAX_VALUE);
		// Float information
		/*
		 * To print out scientific notation for float and double numbers in printf()
		 * method, this formula is from TheSeverSide Reference: How to use Java printf
		 * to format output
		 * https://www.theserverside.com/blog/Coffee-Talk-Java-News-Stories-and-Opinions
		 * /How-to-use-Java-printf-to-format-output#:~:text=Scientific%20notation%20in%
		 * 20Java%20with,f%20to%20specify%20the%20variables.&text=Notice%20how%20this%
		 * 20example%20prints,what%20the%20preceding%20example%20generates. (accessed
		 * June 22,2023)
		 */
		System.out.printf("float," + "SIZE: " + "%d,BYTES: " + "%d,MIN_VALUE: " + "%e,MAX_VALUE: " + "%e %n",
				Float.SIZE, Float.BYTES, Float.MIN_VALUE, Float.MAX_VALUE);
		// Double information
		System.out.printf("double," + "SIZE: " + "%d,BYTES: " + "%d,MIN_VALUE: " + "%e,MAX_VALUE: " + "%e %n",
				Double.SIZE, Double.BYTES, Double.MIN_VALUE, Double.MAX_VALUE);
		// Character information
		// change the data type to integer
		int minValueChar = (int) Character.MIN_VALUE;
		int maxValueChar = (int) Character.MAX_VALUE;
		System.out.printf("char," + "SIZE: " + "%d,BYTES: " + "%d,MIN_VALUE: " + "%d,MAX_VALUE: " + "%d %n",
				Character.SIZE, Character.BYTES, minValueChar, maxValueChar);
		System.out.println("Program by Hong Phong Nguyen");
		System.out.println("Student number : 041099229");
		System.out.println("Course name – Computer Programming");
	}
}
