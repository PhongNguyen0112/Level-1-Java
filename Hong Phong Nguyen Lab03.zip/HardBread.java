/*Assessment: Lab Excersixe 02
Student Name: Hong Phong Nguyen
Student Number: 041099229
Lab Professor Name: David Houtman
Lab Section Number: CST8116 341
Due Date: June 23,2023*/
public class HardBread {
	public final double MAX_LENGTH = 10.5;
	public final double MAX_WIDTH = 10.5;
	public final double MAX_DEPTH = 5.5;
	private double length;
	private double width;
	private double depth;
	private boolean isSalted;

// no-argument constructor
	public HardBread() {
		this.isSalted = true;
	}

// constructor with parameters
	public HardBread(double length, double width, double depth, boolean isSalted) {
		this.length = length;
		this.width = width;
		this.depth = depth;
		this.isSalted = isSalted;
	}

// getter and setter
	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public double getDepth() {
		return depth;
	}

	public void setDepth(double depth) {
		this.depth = depth;
	}

	public boolean isSalted() {
		return isSalted;
	}

	public void setSalted(boolean isSalted) {
		this.isSalted = isSalted;
	}

// calculateVolume method
	public double calculateVolume() {
		return length * width * depth;
	}

//toString
	// %s is for String, %.2f to make double values with 2 decimal places
	public String toString() {
		String result = String.format("Length " + "%.2f, Width " + "%.2f, Depth " + "%.2f", length, width, depth);
		return result;
	}
}
