/*Assessment: Lab Excersixe 02
Student Name: Hong Phong Nguyen
Student Number: 041099229
Lab Professor Name: David Houtman
Lab Section Number: CST8116 341
Due Date: June 23,2023*/
public class Programm {
	public static void main(String[] args) {
		// make an object with HardBread data type
		HardBread hardBread1 = new HardBread();
		HardBread hardBread2 = new HardBread(2.5, 5.75, 3.45, true);
		String report;
		double volume;
		// hardBread1
		volume = hardBread1.calculateVolume();// call calculateVolume() method
		report = hardBread1.toString();// call toString() method
		System.out.println("Hard Bread 1:");
		System.out.printf("%s %.2f %n", "volume:", volume);// using printf() to format values to 2 decimal places
		System.out.println(report);
		// hardBread2
		volume = hardBread2.calculateVolume();// call calculateVolume() method
		report = hardBread2.toString();// call toString() method
		System.out.println("Hard Bread 2:");
		System.out.printf("%s %.2f %n", "volume:", volume);// using printf() to format values to 2 decimal places
		System.out.println(report);
		System.out.print("Program by Hong Phong Nguyen");
	}
}
